#ifndef __PARSER_H__
#define __PARSER_H__

#include "tinyvps.h"

void port_parsing(char *value, vm *newVm);

#endif  // __PARSER_H__