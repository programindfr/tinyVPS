#ifndef __CREATE_H__
#define __CREATE_H__

#include "tinyvps.h"

void create_vm(char *newargv[], char *newenvp[]);
void dcreate_vm(vm *newVm);

#endif  // __CREATE_H__