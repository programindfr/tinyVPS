#ifndef __CONCAT_H__
#define __CONCAT_H__

char* concat(int count, ...);

#endif  // __CONCAT_H__